-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2018 at 10:10 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.1.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `dr_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `dr_id` int(11) NOT NULL,
  `dr_name` varchar(50) NOT NULL,
  `dr_degree` varchar(50) NOT NULL,
  `dr_specialization` varchar(50) NOT NULL,
  `dr_location` varchar(50) NOT NULL,
  `dr_timing` time NOT NULL,
  `disease` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`dr_id`, `dr_name`, `dr_degree`, `dr_specialization`, `dr_location`, `dr_timing`, `disease`) VALUES
(1, 'Dr. Ravishankar Reddy C. R.', 'MBBS, MD - General Medicine, DNB - Neurology', 'General Physician', 'Mumbai', '19:00:00', 'Malaria'),
(2, '\r\nDr. Parthasarathi Dutta Roy', 'B.Sc, MBBS, DDVL, MD - Dermatology', 'Dermatologist, Trichologist, Cosmetologist', 'Mumbai', '10:30:00', 'Acne,Allergy'),
(3, '\r\nDr. Kukreja A. Kalani', 'MD - Homeopathy, DHMS', 'Dermatologist, Homoeopath', 'Mumbai', '12:30:00', 'Allergy'),
(4, '\r\nDr. Indu Bubna', 'Diploma in Tuberculosis and Chest Diseases (DTCD),', 'Pulmonologist, Tuberculous and chest Diseases ', 'Mumbai', '09:30:00', 'Asthma');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `symptom_id` int(11) NOT NULL,
  `dr_specialization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `symptom_id` int(11) NOT NULL,
  `symptom_for` varchar(500) NOT NULL,
  `symptoms` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`symptom_id`, `symptom_for`, `symptoms`) VALUES
(1, 'Acne', 'Blackheads,whiteheads,pimples,oily skin,scarring,pigmentation'),
(2, 'Allergy', 'Red eyes,itchy rash,runny nose,shortness of breath,swelling,sneezing'),
(3, 'Asthma', 'wheezing,coughing,chest tightness,shortness of breath'),
(4, 'Diarrhea', 'Loose motions,dehydrations,fatigue'),
(5, 'Hypothyroidism', 'cold,feeling tired,constipation,weight gain,fatigue,poor memory,poor concentration,shortness of breath,hoarse voice,poor hearing,abnormal sensation'),
(6, 'Influenza', 'fever,runny nose,sore throat,muscle pains,headache,coughing,sneezing,feeling tired'),
(7, 'Kidney stone', 'Severe pain,lower back pain,abdomen pain,blood urine,vomiting,nausea'),
(8, 'Parkinson', 'Shaking,rigidity,slowness of movement,difficulty walking'),
(9, 'Malaria', 'high fever,fever,vomiting,headache'),
(10, 'Migrane', 'headaches,nausea,sensitivity to light,sensitivity to sound,sensitivity to smell');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(20) NOT NULL,
  `user_lname` varchar(20) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `user_dob` date NOT NULL,
  `user_phone` bigint(20) NOT NULL,
  `user_gender` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_fname`, `user_lname`, `user_email`, `user_password`, `user_dob`, `user_phone`, `user_gender`) VALUES
(1, 'abc', 'abc', 'abcd@gmail.com', '123', '2015-08-09', 9876543210, ''),
(4, 'xyz', 'xyz', 'xyz@gmail.com', '123', '2015-03-11', 9876543210, ''),
(10, 'flx', 'flx', 'flx@gmail.com', '123', '2018-10-05', 9876543111, 'F'),
(13, '', '', '', '', '0000-00-00', 0, 'F'),
(14, 'aman', 'preet', 'amanpreet@gmail.com', '123', '2018-10-01', 9876969696, 'M'),
(15, 'test', 'test', 'test@gmail.com', '123', '2010-02-04', 1234568970, 'M'),
(16, 'test2', 'test2', 'test2@gmail.com', '123', '2010-05-23', 8454883072, 'M'),
(17, 'deepali', 'panda', 'deepali@gmail.com', '123', '2005-11-27', 9898989898, 'F'),
(18, 'disha', 'kanishka', 'disha@gmail.com', '123', '2012-05-05', 1254789630, 'F'),
(19, 'ashu', 'tambe', 'ashu@gmail.com', '123', '2015-02-05', 1234568970, 'M'),
(20, 'srbh', 'singh', 'srbhsingh39@gmail.com', '123', '2009-11-23', 8454883075, 'M'),
(21, 'ruchi', 'ruchi', 'ruchi@gmail.com', '123', '2009-07-21', 1100330011, 'F');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`dr_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `symptom_id` (`symptom_id`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`symptom_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`,`user_phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `dr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `symptom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `symptom_id` FOREIGN KEY (`symptom_id`) REFERENCES `symptoms` (`symptom_id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`history_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
