<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Health-io</title>
	<?php include('api/links.php')?>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom" style="height:100%">

<div id="wrapper">
	<?php include("include/navbar.php")?>	    
    <section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
						<h2 class="h-ultra">Health-io medical group</h2>
					</div>
					<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
						<h4 class="h-light">Provide <span class="color">best quality healthcare</span> for you</h4>
					</div>
					<div class="well well-trans">
						<div class="wow fadeInRight" data-wow-delay="0.1s">
							<ul class="lead-list">
								<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Don't know what you are suffering from?</strong><br />Tell us what you are facing....</span></li>
								<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Busy Enough to stand in Hospital queues?</strong><br />Place an appoinment to your Doctor in a minute :-)</span></li>
								<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Got checkups? Finding it hard to remember?</strong><br />Get reminders of your daily medicines and routine checkup.</span></li>
							</ul>

						</div>
					</div>


				</div>
				<div class="col-lg-6">
				<?php include('include/login_signup.php')?>
			</div>
            </div>
        </div>
						
				</div>			
			</div>
		</div>		
    </section>
    
	<?php include('include/emergencybox.php') ?>
	<?php include('include/services.php') ?>
	<?php include('include/highlights.php')?>
        </div>
    </div>
</div>	 
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a> 
<?php include("include/footer.php")?>

<script type="text/javascript">
	$(document).ready(function(){
		var details;
		// Prevent Default Functionality on form submission
		$("#signup").on("submit", function(event){
			var dob=document.forms["myform"]["dob"].value;
			if(document.forms["myform"]['gender'].value=="M"){
				var user_gender="M";
			}
			else{
				var user_gender="F";
			}
			var pass=document.forms["myform"]["password"].value;
			var re_pass=document.forms["myform"]["re_password"].value;
			if(pass!=re_pass){
				$('#nomatch').html("User Already Exists.");
			}
			else{
			details = {
				'user_fname':$('#first_name').val(),
				'user_lname':$('#last_name').val(),
				'user_email':$('#email').val(),
				'user_password':$('#password').val(),
				're_password':$('#re_password').val(),
				'user_dob':dob,
				'user_phone':$('#phone').val(),
				'user_gender':user_gender,
				'function':'checkEmail',
			};
			console.log(details);
			event.preventDefault();
			details.function="register";
			
			$.post("api/users.php",{'details':details}, function(bool_exist){
				console.log(parseInt(bool_exist));
				if(bool_exist == 1){
					$('#user_exist').html("User Already Exists.");
				} 
			});
			}
		});

		$("#submit_login").on("click", function(event){
			event.preventDefault();
			details = {};
			details.function = "login";
			details.user_email = $("#email_log").val();
			details.user_password = $("#password_log").val();
			event.preventDefault();
			// Check if Email Exists.
			console.log(details);
			$.post("api/users.php",{'details':details}, function(page){
				window.location.href = page;
			});
		});


	});
</script>


</body>

</html>
