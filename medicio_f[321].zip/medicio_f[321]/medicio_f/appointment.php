<?php
include_once("api/users.php");
if (!isset($_SESSION['uid'])) {
  header("Location:	index.php");

}
include_once("api/definations.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Take appointments in secs!!!</title>
    <script src="https://use.typekit.net/fjq2gnx.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel="stylesheet" href="cssar/style2.css">

  <link rel='stylesheet prefetch' href='http://dfcb.github.io/extra-strength-responsive-grids/css/grid.css'>
<link rel='stylesheet prefetch' href='http://thisisstar.com/images/100UI/002/css/paymentfont.css'>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

    <?php include("api/links.php") ?>

 <body class="settings"  id="page-top" data-spy="scroll" data-target=".navbar-custom" style="background-color:#f2f9fe">
 
<?php include('include/navbar1.php') ?>
<div>
    <div class="max-width">
      <section class="payment turquoise">
        <div class="grid-whole padded-reverse">
          <div class="grid-whole padded">
            <h3>Get Appointment</h3>
            <hr>
          </div>
          <?php     
            $con=Connection();
            $id=$_SESSION['uid'];
            $sql="SELECT  * from history where `user_id`=$id";
          ?>
          <div class="grid-12 padded m-grid-whole s-grid-whole xs-grid-whole">
            <form id="set_reminder" action="appointlast.php" accept-charset="UTF-8" method="post">
              <input name="utf8" type="hidden" value="Ã¢Å“â€œ">
  <div class="grid-whole">
              <div class="grid-whole padded">
                <label for="location">
                  <span class="upper-bryant small-bold">Enter your location</span>
                </label>
                <input type="text" class="space" size="20" name="location" id="location">
              </div>
</div>


                    <div class="grid-whole">
                      <div class="grid-whole padded" >
                        <label for="specialist">
                          <span class="upper-bryant small-bold">Specialist</span>
                        </label>
                        <input type="text"  placeholder="example:Dermatologist" class="space" size="20" name="specialist" id="specialist">
                      </div>
                      </div>


              <button type="submit" class="btn" id="set_remind">Get Appointment</button>
              <button type="reset" class="btn" id="reset_remind">Reset Appointment</button>


            </form>
          </div>
          <div class="clear"></div>
        </div>
      </section>
    </div>
  </div>
<br><br><br><br><br><br>
<?php include('include/footer.php') ?>    
</body>
</html>