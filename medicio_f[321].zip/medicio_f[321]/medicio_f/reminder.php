<?php
	include_once("api/users.php");
	if(!isset($_SESSION['uid'])){
		header("Location:	index.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Set reminder</title>
    <script src="https://use.typekit.net/fjq2gnx.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel="stylesheet" href="cssar/style2.css">

  <link rel='stylesheet prefetch' href='http://dfcb.github.io/extra-strength-responsive-grids/css/grid.css'>
<link rel='stylesheet prefetch' href='http://thisisstar.com/images/100UI/002/css/paymentfont.css'>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>


    <?php include("api/links.php")?>
</head>
  <body class="settings"  id="page-top" data-spy="scroll" data-target=".navbar-custom" style="background-color:#ccebff">
<?php include('include/navbar1.php')?>



<div>
    <div class="max-width">
      <section class="payment turquoise">
        <div class="grid-full padded-reverse">
          <div class="grid-whole padded">
            <h3>Set Reminder</h3>
            <hr>
          </div>

          <div class="grid-12 padded m-grid-whole s-grid-whole xs-grid-whole">
            <form id="set_reminder" action="remindlast.php" accept-charset="UTF-8" method="post">
              <input name="utf8" type="hidden" value="âœ“">
  <div class="grid-whole">
              <div class="grid-4 padded">
                <label for="height">
                  <span class="upper-bryant small-bold">Height</span>
                </label>
                <input type="number" class="space" size="20" name="height" id="height">
              </div>

              <div class="grid-4 padded">
                <label for="weight">
                  <span class="upper-bryant small-bold">Weight</span>
                </label>
                <input type="number" class="space" size="20" name="weight" id="weight">
              </div>

              <div class="grid-4 padded" >
                <label for="blood_group">
                  <span class="upper-bryant small-bold">Blood Group</span>
                </label>
                <input type="text" class="space" size="20" name="blood_group" id="blood_group">
              </div>
            </div>

              <div class="grid-whole">
                <div class="grid-whole padded" >
                  <label for="sdisease">
                    <span class="upper-bryant small-bold">Suffering from diseases</span>
                  </label>
                  <input type="text" class="space" size="20" name="sdisease" id="sdisease">
                </div>
                </div>

                <div class="grid-whole">
                  <div class="grid-whole padded" >
                    <label for="medicine">
                      <span class="upper-bryant small-bold">Regular Medicines</span>
                    </label>
                    <input type="text" class="space" size="20" name="medicine" id="medicine">
                  </div>
                  </div>

                  <div class="grid-whole">
                    <div class="grid-6 padded">
                      <label for="med_count">
                        <span class="upper-bryant small-bold">Count of Medicines</span>
                      </label>
                      <input type="number" class="space" size="20" name="med_count" id="med_count">
                    </div>

                    <div class="grid-6 padded">
                      <label for="med_time">
                        <span class="upper-bryant small-bold">Timing for Medicines</span>
                      </label>
                      <input type="time" class="space" size="20" name="med_time" id="med_time">
                    </div>
                    </div>


                    <div class="grid-whole">
                      <div class="grid-whole padded" >
                        <label for="dr_name">
                          <span class="upper-bryant small-bold">Doctor's Name</span>
                        </label>
                        <input type="text"  placeholder="Name of the Doctor by whom treatment is ongoing" class="space" size="20" name="dr_name" id="dr_name">
                      </div>
                      </div>

                      <div class="grid-whole">
                        <div class="grid-whole padded" >
                          <label for="r_check">
                            <span class="upper-bryant small-bold">Taken Routine checkup for</span>
                          </label>
                          <input type="text" placeholder="example:Thyroid" class="space" size="20" name="r_check" id="r_check">
                        </div>
                      </div>
                      <div class="grid-whole">
                        <div class="grid-whole padded" >
                          <label for="r_freq">
                        <span class="upper-bryant small-bold">Frequency of Routine checkup</span>
                          </label>
                          <input type="number" class="space" size="20" name="r_freq" id="r_freq">
                        </div>
                        </div>

              <button type="submit" class="btn" id="set_remind" href="remindlast.php">Set Reminder</button>
              <button type="reset" class="btn" id="reset_remind">Reset Reminder</button>


            </form>
          </div>
          <div class="clear"></div>
        </div>
      </section>
    </div>
  </div>

<br><br><br><br><br><br>


<?php include('include/footer.php')?>    
</body>
</html>