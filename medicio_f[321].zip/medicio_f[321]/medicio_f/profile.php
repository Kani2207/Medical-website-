﻿<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Blueprint: A basic template for a page stack navigation effect" />
	<meta name="keywords" content="blueprint, template, html, css, page stack, 3d, perspective, navigation, menu" />
	<meta name="author" content="Codrops" />
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Health.io-Profile</title>
		<link rel="stylesheet" href="https://use.typekit.net/bsg5ydy.css">
		<link rel="stylesheet" type="text/css" href="css/base.css" />
		<script>
		document.documentElement.className = "js";
		var supportsCssVars = function() { var e, t = document.createElement("style"); return t.innerHTML = "root: { --tmp-var: bold; }", document.head.appendChild(t), e = !!(window.CSS && window.CSS.supports && window.CSS.supports("font-weight", "var(--tmp-var)")), t.parentNode.removeChild(t), e };
		supportsCssVars() || alert("Please view this demo in a modern browser that supports CSS Variables.");
		</script>
	</head>
	<body>
			<main>			<div class="slideshow">
				<div class="slide">
					<div class="slide__img-wrap">
						<div class="slide__img" style="background-image: url(img/7.jpg);"></div>
						<div class="slide__img-reveal"></div>
					</div>
					<div class="slide__title-wrap">
						<h3 class="slide__title"><div class="slide__box"></div><span class="slide__title-inner">Dont Know</span></h3>
						<h4 class="slide__subtitle"><div class="slide__box"></div><span class="slide__subtitle-inner">what you are suffering from?</span></h4>
						<p class="slide__quote"><em>Tell us what you are facing....</em></p>
						<a class="slide__explore" href="symptoms.php" ><span class="slide__explore-inner">Get Help</span></a>
					</div>
								</div>
				<div class="slide">
					<div class="slide__img-wrap">
						<div class="slide__img" style="background-image: url(img/8.jpeg);"></div>
						<div class="slide__img-reveal"></div>
					</div>
					<div class="slide__title-wrap">
						<h3 class="slide__title"><div class="slide__box"></div><span class="slide__title-inner">Busy Enough</span></h3>
						<h4 class="slide__subtitle"><div class="slide__box"></div><span class="slide__subtitle-inner">to stand in hospital queues?</span></h4>
						<p class="slide__quote"><em>Place an appointment to your Doctor in a minute</em></p>
						<a class="slide__explore" href="appointment.php" ><span class="slide__explore-inner">Get appointment</span></a>
					</div>
								</div>
				<div class="slide">
					<div class="slide__img-wrap">
						<div class="slide__img" style="background-image: url(img/10.jpg);"></div>
						<div class="slide__img-reveal"></div>
					</div>
					<div class="slide__title-wrap">
						<h3 class="slide__title"><div class="slide__box"></div><span class="slide__title-inner">Got checkups</span></h3>
						<h4 class="slide__subtitle"><div class="slide__box"></div><span class="slide__subtitle-inner">Finding it hard to remember</span></h4>
						<p class="slide__quote"><em>Get reminders of your daily medicines and routine checkup</em> </p>
						<a class="slide__explore" href="reminder.php" ><span class="slide__explore-inner">Set reminder</span></a>
					</div>

				</div>
				<div class="slide">
					<div class="slide__img-wrap">
						<div class="slide__img" style="background-image: url(img/9.jpg);"></div>
						<div class="slide__img-reveal"></div>
					</div>
					<div class="slide__title-wrap">
						<h3 class="slide__title"><div class="slide__box"></div><span class="slide__title-inner">Need Equipments</span></h3>
						<h4 class="slide__subtitle"><div class="slide__box"></div><span class="slide__subtitle-inner">but finding them costly </span></h4>
						<p class="slide__quote"><em>Get medicines and other stuff at reasonable price</em></p>
						<a class="slide__explore" href="equip.php" ><span class="slide__explore-inner">Buy Hospitals equipments </span></a>
					</div>
					</div>
						</div>
		</main>
		<div class="loader">
			<div class="loader__inner"></div>
		</div>
		<script src="js/imagesloaded.pkgd.min.js"></script>
		<script src="js/TweenMax.min.js"></script>
		<script src="js/demo.js"></script>
	</body>
</html>
