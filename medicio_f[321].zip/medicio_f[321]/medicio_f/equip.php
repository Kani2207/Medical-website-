<?php
	include_once("api/users.php");
	if(!isset($_SESSION['uid'])){
		header("Location:	index.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Search in our Doctropedia!!</title>
    
    <link href="csse/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary JavaScript plugins) -->
<script type='text/javascript' src="jse/jquery-1.11.1.min.js"></script>
<!-- Custom Theme files -->
<link href="csse/style.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Medical_Equipment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- start menu -->
<script type="text/javascript" src="jse/bootstrap.js"></script>

<script src="jse/simpleCart.min.js"> </script>
<script src="jse/responsiveslides.min.js"></script>
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
	
  </script>
<script type="text/javascript" src="jse/move-top.js"></script>
       <script type="text/javascript" src="jse/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
		<script type="text/javascript">
		$(document).ready(function() {
				
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>

    <?php include("api/links.php")?>
</head>
<body>
<?php include('include/navbar1.php')?>  
<br><br><br>

<div class="banner">
	<div class="container">
		<div class="col-md-12 banner-left">
			<div class="header-slider">
				<div class="slider">
					<div class="callbacks_container">
					  	<ul class="rslides" id="slider">
							<li>
								<img src="imagese/3.jpg" class="img-responsive" alt="" height="500px">
						
							</li>
							<li>
								<img src="imagese/2.jpg" class="img-responsive" alt="">
								
							</li>
							<li>
								<img src="imagese/0.jpg" class="img-responsive" alt="">
							</li>
						</ul>
			  		</div>
				 </div>
				</div>
		</div>
		<br><br><br>
	
<!-- end banner -->

<div class="special">
	<div class="container">
		<div class="specia-top">
			<ul class="grid_2">
		<li>
				<a href="sale.html"><img src="imagese/8.jpg" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Surgical Bed</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 5000.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
				</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/9.jpg" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Wheel Chair</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 1000.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
			</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/11.jpeg" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Syringe</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 50.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
			</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/12.png" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Thermometer</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 300.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
				</div>
		</li>
		<div class="clearfix"> </div>
	</ul>
		</div>
	</div>
</div>
<!-- special -->
<div class="special">
	<div class="container">
		<div class="specia-top">
			<ul class="grid_2">
		<li>
				<a href="sale.html"><img src="imagese/13.jpg" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Weighing Scale</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 500.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
				</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/14.png" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Blood Pressure Monitor</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 800.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
			</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/7.png" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>Stethoscope</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 200.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
			</div>
		</li>
		<li>
				<a href="sale.html"><img src="imagese/5.jpg" class="img-responsive" alt=""></a>
				<div class="special-info grid_1 simpleCart_shelfItem">
					<h5>First Aid Box</h5>
					<div class="item_add"><span class="item_price"><h6>ONLY Rs 200.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Add to cart</a></span></div>
				</div>
		</li>
		<div class="clearfix"> </div>
	</ul>
		</div>
	</div>
</div>
<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span> <span id="toTopHover" style="opacity: 0;"> </span></a>
</div></div>
</body>

<?php include('include/footer.php')?>    
</html>