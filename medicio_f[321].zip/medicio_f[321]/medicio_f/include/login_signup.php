<div class="span12" id="login_signup">
    		<div class="" id="loginModal">
              <div class="modal-body">
                <div class="well">
                  <ul class="nav nav-tabs">
                    <li ><a href="#login" data-toggle="tab">Login</a></li>
                    <li class="active"><a href="#create" data-toggle="tab">Create Account</a></li>
                  </ul>
                  <div id="myTabContent" class="tab-content">
                    <div class="tab-pane fade" id="login">
                      <form id="loginform" class="form-horizontal" >
                        <fieldset>
                           
                          <div class="row">
											<div class="col-xs-12 col-sm-12 col-md-12">
												<div class="form-group">
													<label>Email</label>
													<input type="email" name="email" id="email_log" class="form-control input-md" required>
												</div>
											</div>
											
										</div>
										<div class="row">
											<div class="col-xs-12 col-sm-12 col-md-12">
												<div class="form-group">
													<label>Password</label>
													<input type="password" name="password" id="password_log" class="form-control input-md" required>
												</div>
											</div>
							</div>
                          <div class="control-group">
                    
                            <div class="controls" style="margin-left:40%">
                             <input type="submit" value="Login" id="submit_login" class="btn btn-skin btn-lg">
                            </div>
                          </div>
                        </fieldset>
                      </form>                
                    </div>
                    <div class="tab-pane active in" id="create">
                      <form id="signup"  method="post" name="myform">
                        <div class="row">
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>First Name</label>
													<input type="text" name="first_name" id="first_name" class="form-control input-md" required>
												</div>
											</div>
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>Last Name</label>
													<input type="text" name="last_name" id="last_name" class="form-control input-md" required>
												</div>
											</div>
										</div>

										<div class="row">
											<div class="col-xs-12 col-sm-12 col-md-12">
												<div class="form-group">
													<label>Email</label>
													<input type="email" name="email" id="email" class="form-control input-md" required>
													<span id="user_exit"></span>
												</div>
											</div>
											
										</div>
										<div class="row">
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>Password</label>
													<input type="password" name="password" id="password" class="form-control input-md" required>
												</div>
											</div>
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>Re-Enter Password</label>
													<input type="password" name="re_password" id="re_password" class="form-control input-md" required>
													<span id="nomatch"></span>
												</div>
											</div>
										</div>		
										<div class="row">
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>D.O.B</label>
													<input type="date" name="dob" id="dob" class="form-control input-sm" required>
												</div>
											</div>
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label>Phone number</label>
													<input type="text" name="phone" id="phone" class="form-control input-md" required>
												</div>
											</div>
										<div class="row" style="margin-left:0%">
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
													<label class="radio-inline">
      													<input type="radio"  name="gender" value="M">Male
													</label>
												</div>
											</div>
											<div class="col-xs-6 col-sm-6 col-md-6">
												<div class="form-group">
    												<label class="radio-inline">
      													<input type="radio"  name="gender" value="F">Female
    												</label>
												</div>
											</div>
										</div>
										<input type="submit" value="Register" id="tab" class="btn btn-skin btn-block btn-sm">				
                      </form>
                    </div>
                </div>
              </div>