
<?php

	define('__ROOT__', dirname(dirname(__FILE__)));
	include_once(__ROOT__.'/api/core.php');	
?>