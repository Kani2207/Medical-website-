<?php
	session_start();

	include_once("definations.php");

	if(!isset($_POST['details'])){
		if(empty($_SESSION['uid']) || !isset($_SESSION['uid']))  {
			header("Location:http://127.0.0.1/medicio/index.php");
			die("");
		}
		$user_obj = getUser($_SESSION['uid']);
	}
	else{
		$details = $_POST['details'];
		callFunction($details);
	}
	
	function register($details){
		$user_fname = $details['user_fname'];
		$user_lname = $details['user_lname'];
		$user_email = $details['user_email'];
		$user_password = $details['user_password'];
		$user_dob = $details['user_dob'];
		$user_phone = $details['user_phone'];
		$user_gender =$details['user_gender'];
	
		$sql = "INSERT INTO `user`(`user_fname`,`user_lname`,`user_email`, `user_password`, `user_dob`,`user_phone`,`user_gender`) VALUES ('$user_fname','$user_lname','$user_email','$user_password','$user_dob','$user_phone','$user_gender')";
		$con = connection();
		$result = $con->query($sql);
		$lastid = $con->insert_id;
		$con->close();
	
		return false;
	}
	function getUser($uid){
		$sql = "Select `user_fname`,`user_email`,`user_phone` from `user` where `user_id` = $uid";
		$con = connection();
		$result = $con->query($sql);
		$con->close();
		return $result;
	}
	function login($details){
		$password = $details['user_password'];
		$username = $details['user_email'];
		#echo $password;
		$con = connection();
		$sql = "Select `user_id` from `user` where `user_email` = '".$username."' and `user_password` = '".$password."'";
		$result = $con->query($sql);
		
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			$_SESSION['uid'] = $row['user_id'];
			return true;
		}
		$con->close();
		return false;
	}

	function checkEmail($details){
		$sql = "Select 1 from `imp_user` where `email` = '".$details['imp_email']."'";
		$con = connection();
		$result = $con->query($sql);
		$con->close();
		$row = ($result->num_rows)?"1":"0";
		return $row;
	}

	function checkPassword($details){
		$user_password = $details['user_password'];
		$re_password = $details['re_password'];
		if($user_password!=re_password){
			return 2;
		}
	}

	function callFunction($details){
		switch ($details['function']) {
			case 'register':
				$result = (register($details))?"profile.php":"error.php";
				break;
			case 'check_email':
				$result = checkEmail($details);
				break;
			case 'login':
				$result = login($details)?"profile.php":"error.1.php";
				break;
			default:
				$result = false;
				break;
		}
		die($result);
		return $result;
	}
?>
