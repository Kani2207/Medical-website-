<?php
	function connection(){
		$database=[
		'servername'=>'localhost',
		'username'=>'root',
		'password'=>'',
		'dbname'=>'health'
		];
	// connecting to Database
	$con = new mysqli($database['servername'],$database['username'],$database['password'],$database['dbname']);
		// Check connection
		if ($con->connect_error) {
	    	die("Connection failed: " . $con->connect_error);
		}
		
		return $con;
		
	}

	$_SESSION['basic_load'] = 1;
?>
