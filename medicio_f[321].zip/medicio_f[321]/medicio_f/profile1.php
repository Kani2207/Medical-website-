<?php
	include_once("api/users.php");
	if(!isset($_SESSION['uid'])){
		header("Location:	index.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Profile</title>
	<?php include("api/links.php")?>
</head>
<body>
	<div id="wrapper">
	<?php include("include/navbar.php")?>	    
    <section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
		<div class="control-group">
            <div class="controls" style="margin-left:40%">
				<a href="symptoms.php">
                	<input type="submit" value="Symptoms" id="symptoms_btn" class="btn btn-skin btn-lg">
				</a>
            </div>
        </div>

		<div class="control-group">
            <div class="controls" style="margin-left:40%">
				<a href="appointment.php">
            		<input type="submit" value="Appointment" id="appointment_btn" class="btn btn-skin btn-lg">
				</a>
            </div>
        </div>
		</div>
		<div class="control-group">  
            <div class="controls" style="margin-left:40%">
				<a href="disease.php">
                	<input type="submit" value="Diseases" id="diseases_btn" class="btn btn-skin btn-lg">
				</a>
            </div>
        </div>
		<div class="control-group">  
            <div class="controls" style="margin-left:40%">
				<a href="doctors.php">
                	<input type="submit" value="Doctors" id="diseases_btn" class="btn btn-skin btn-lg">
				</a>
            </div>
        </div>
</div>
</div>
<?php include('include/footer.php')?>
</body>

</html>