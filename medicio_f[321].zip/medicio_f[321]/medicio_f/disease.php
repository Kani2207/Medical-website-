<?php
include_once("api/users.php");
include_once("api/definations.php");
if (!isset($_SESSION['uid'])) {
  header("Location:	index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Search about Diseases,symptoms</title>
    <script src="https://use.typekit.net/fjq2gnx.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel="stylesheet" href="cssar/style2.css">

  <link rel='stylesheet prefetch' href='http://dfcb.github.io/extra-strength-responsive-grids/css/grid.css'>
<link rel='stylesheet prefetch' href='http://thisisstar.com/images/100UI/002/css/paymentfont.css'>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>

    <?php include("api/links.php") ?>
    <?php include('include/navbar1.php') ?>
</head>
  <body class="settings"  id="page-top" data-spy="scroll" data-target=".navbar-custom">


 <div>
    <div class="max-width">
      <section class="payment turquoise">
        <div class="grid-full padded-reverse">
          <div class="grid-whole padded">
            <h3>DISEASES</h3>
            <hr>
          </div>

		  
        <?php 
        $symp1 = $_POST['symp1'];
        $symp2 = $_POST['symp2'];
        $symp3 = $_POST['symp3'];
        $symp4 = $_POST['symp4'];
        $symp5 = $_POST['symp5'];
        $symptoms = $symp1 . "," . $symp2 . "," . $symp3 . "," . $symp4 . "," . $symp5 . "";
        //echo $symptoms;
        $symptoms = rtrim($symptoms, ",");
        $con = connection();
        $sql = "SELECT symptom_for,symptom_id FROM symptoms WHERE symptoms LIKE '$symptoms%'";
        //echo "Hello";

        $result = $con->query($sql);
        //var_dump($result);
        if ($result) {
          $row = $result->fetch_row();
          echo "<h6><em>Diseases match found:</em></h6>";
          echo "<h1 style='margin-left:40%'>$row[0]</h1>";
          $disease = $row[1];
          //var_dump($row);
        }
        echo "<h6>Specialists You Need:</h6>";
        $sql = "SELECT dr_specialization from doctor where disease='$row[0]'";
        $result = $con->query($sql);
        //var_dump($result);
        //$specialization = "";
        if ($result) {
          $row = $result->fetch_row();
          echo "<h1 style='margin-left:40%'>$row[0]</h1>";
          $specialization = $row[0];
        }
        $id = $_SESSION['uid'];
        $sql = "INSERT INTO `history`(`user_id`,`symptom_id`,`dr_specialization`) values($id,'$disease','$specialization')";
        $result = $con->query($sql);
        //var_dump($sql);
        //var_dump($result);
        // if ($result) {
        //   echo $id . "" . $disease . "" . $specialization . "";
        // }
        ?>

        <div>
        <a href="appointment.php">
        <button type="submit" class="btn" id="get_appoint">GET APPOINTMENT</button>
        </a>
        </div>
          <!-- <div class="grid-12 padded m-grid-whole s-grid-whole xs-grid-whole">
            <form id="set_reminder" action="/cards" accept-charset="UTF-8" method="post">
              <input name="utf8" type="hidden" value="âœ“">
  <div class="grid-whole">
              <div class="grid-4 padded">
                <label for="symp1">
                  <span class="upper-bryant small-bold"> SYMPTON 1</span>
                </label>
                <input type="text" class="space" size="20" name="symp1" id="symp1">
              </div>

              <div class="grid-4 padded">
                <label for="symp2">
                  <span class="upper-bryant small-bold"> SYMPTON 2</span>
                </label>
                <input type="text" class="space" size="20" name="symp2" id="symp2">
              </div>

              <div class="grid-4 padded" >
                <label for="symp3">
                  <span class="upper-bryant small-bold"> SYMPTON 3</span>
                </label>
                <input type="text" class="space" size="20" name="symp3" id="symp3">
              </div>
            </div>

              <div class="grid-whole">
                <div class="grid-whole padded" >
                  <label for="symp4">
                    <span class="upper-bryant small-bold"> SYMPTON 4</span>
                  </label>
                  <input type="text" class="space" size="20" name="symp4" id="symp4">
                </div>
                </div>

				<div class="grid-whole">
                <div class="grid-whole padded" >
                  <label for="symp5">
                    <span class="upper-bryant small-bold"> SYMPTON 5</span>
                  </label>
                  <input type="text" class="space" size="20" name="symp5" id="symp5">
                </div>
                </div>
                
              <button type="submit" class="btn" id="set_remind">GET DISEASES</button>
              <button type="reset" class="btn" id="reset_remind">RESET DISEASES</button>


            </form>-->
          </div>
          <div class="clear"></div>
        </div>
      </section>
    </div>
  </div>
<br><br><br><br><br><br>
 


    
</body>
<?php include('include/footer.php') ?>
</html>